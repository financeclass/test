from SinaWeibo import Weibo

wb= Weibo("15120040939","ssj874jld9")
wb.postMessage("0.2测试1:文本")