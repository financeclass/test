"""dja URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import include, url
from django.contrib import admin
from django.conf.urls.static import static
from django.conf import settings
from appmain import views as appmain_views

urlpatterns = [
url(r'^wxbd/', appmain_views.wx),
url(r'^biaoqing/', appmain_views.biaoqing),

url(r'^testorg/', appmain_views.orgmode),
url(r'^wxcraw/', appmain_views.wxcraw),
url(r'^wxshow/', appmain_views.wxshow),
    url(r'^adad/', admin.site.urls),
    # url(r'^test/$', appmain_views.test),
    url(r'^testh/$', appmain_views.testhtml),
    # url(r'^$', appmain_views.home),
    # url(r'^index/$', appmain_views.index),
    # url(r'^search/', appmain_views.search),
    # url(r'^hot_post/', appmain_views.hot_post),
    # url(r'^posthot/', appmain_views.posthot),
    # url(r'^mark/', appmain_views.mark),
    # url(r'^addone/', appmain_views.addone),
    # url(r'^addlist/', appmain_views.addlist),
    # url(r'^c/(\d+)/', appmain_views.links),
    # url(r'^vote/', appmain_views.vote),
    # url(r'^a/(\d+)/', appmain_views.detail),
    # url(r'^hotlink/(\d+)/', appmain_views.hotlink),
    # url(r'^r/(\d+)/', appmain_views.rank),
    # url(r'^u/(\w+)/(\d+)/', appmain_views.ulinks),
    # url(r'^hot/(\d+)/', appmain_views.hot),
    # url(r'^delete/', appmain_views.delete),
    # url(r'^favlink/', appmain_views.favlink),
    # url(r'^wbrecall/', appmain_views.wbrecall),
    # url(r'^ajaxo/', appmain_views.ajaxo),
    # url(r'^about/', appmain_views.space),
    # url(r'^profileset/', appmain_views.profileset),
    # url(r'^register/', appmain_views.register),
    # url(r'^userlogin/', appmain_views.userlogin),
    # url(r'^userlogout/', appmain_views.userlogout),
    # url(r'^baidu_verify_1scVq4X1Ef.html', appmain_views.file),
]


urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)