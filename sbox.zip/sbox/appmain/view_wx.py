# coding:utf-8
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render, get_object_or_404
from .models import *
from .forms import *
import socket
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from functools import reduce
from django.forms import HiddenInput
from django.conf import settings
import os
from random import choice
import requests
import json
import re
from django.views.decorators.csrf import csrf_exempt
import pandas as pd
from django.db.models import Q


def wxshow(request):
    # site_conf = SiteConf.objects.all()[0]

    # link = get_object_or_404(HotBlog, id=a)
    cates = ['经济', '娱乐', '情感', '影视', '奇谈', '深度',  '美景', '美食', '搞笑']
    yesid = request.GET.get('yesid', None)
    if yesid:
        ww = WxCraw.objects.get(id=yesid)
        ww.isgood = True
        ww.save()
        return HttpResponse('yes')

    ca = request.GET.get('cate', None)
    if ca:
        wxs = WxCraw.objects.filter(~Q(isgood=True)).filter(cate=ca).order_by("-publishDateStr")[:200]

        if wxs:
            df=pd.DataFrame(list(wxs.values()))
            maxtime=df['publishDateStr'].groupby(df['myname']).max().reset_index()
            maxtime.columns=['myname','maxtime']
            df=pd.merge(df,maxtime,on='myname',how='left')
            df=df.sort_values(['maxtime','myname','publishDateStr','isTop','original'],ascending=[ False,True,False,False,False])
            df=pd.concat([df, pd.DataFrame({'lag':df['myname']}).shift()], axis=1)
            wxs=[dict(zip(df.columns,aa)) for aa in df.values]

        wxgood = WxCraw.objects.filter(isgood=True).filter(cate=ca).order_by("-update_time")[:11]
    else:
        wxs = WxCraw.objects.filter(~Q(isgood=True)).order_by("-publishDateStr", "-isTop")[:100]
        wxgood = WxCraw.objects.filter(isgood=True).order_by("-update_time")[:3]
    # hotchannels = HotChannel.objects.filter(state=0).order_by('order')
    # rank = link.channel
    # rankname = rank.name

    if request.method == 'POST':
        new_comment = CommentHot.objects.create(user=request.user if request.user.username else None,
                                                content=request.POST.get('comment', None),
                                                blog=link,
                                                ip=request.META['HTTP_X_FORWARDED_FOR']
                                                if 'HTTP_X_FORWARDED_FOR' in request.META
                                                else request.META['REMOTE_ADDR'])
    # comments = CommentHot.objects.filter(blog=link).order_by('-id')
    return render(request, 'appmain/wx/wxshow.html', locals())

