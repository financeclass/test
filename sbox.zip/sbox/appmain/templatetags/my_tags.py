# coding:utf-8
from django import template
import re
from django.utils.http import urlquote

register = template.Library()


def mytag_link_split(value):
    return ('.').join(value.replace('http://', "").
                          replace('https://', "").replace('www.', "").replace('/', "").replace('?', "").split('.')[:2])


register.filter('mytag_link_split', mytag_link_split)


def mytag_getkey(value, para):
    return value[para]


register.filter('mytag_getkey', mytag_getkey)


def m_getlist(value):
    if value is None:
        return None
    return value.replace('，', ',').split(',')


register.filter('m_getlist', m_getlist)


def parse_url(url, para, value, first_page=True):
    if url.find('/?') == -1:
        return url + '?' + para + '=' + str(value)
    else:
        para_list = url.split('/?')[1].split('&')

        for index, aaa in enumerate(para_list):
            if aaa.split('=')[0] == para:
                para_list[index] = para + '=' + value
            if aaa.split('=')[0] == 'page' and first_page:
                para_list[index] = 'page=1'
        url = url.split('/?')[0] + '/?' + '&'.join(para_list)
        if url.find(para + '=') == -1:
            url = url + '&' + para + '=' + str(value)
        return url


def change_sort(value, para):
    return parse_url(value, 'sort', str(para))


register.filter('change_sort', change_sort)


def change_folder(value, para):
    return parse_url(value, 'folder', str(para))


register.filter('change_folder', change_folder)


def previous_page(value, para):
    return parse_url(value, 'page', str(para - 1), first_page=False)


register.filter('previous_page', previous_page)


def next_page(value, para):
    return parse_url(value, 'page', str(para + 1), first_page=False)


register.filter('next_page', next_page)


def mytag_addtag(value, para):
    if value.find('tag=') == -1:
        return value + '?tag=' + urlquote(para)
    else:
        return re.sub(r'tag=([^<]+)', 'tag=' + para + '*t*' + r'\1', value)


register.filter('mytag_addtag', mytag_addtag)


def mytag_find(value, para):
    for aa in para.split(','):
        if value and value.find(aa) > -1:
            return True
    return False


register.filter('mytag_find', mytag_find)


def mytag_cuturl(value):
    value = value.replace('http://', '')
    value = value.replace('https://', '')
    value = value.replace('www.', '')
    list = value.split('.')
    if len(list) > 1:
        return list[0] + '.' + list[1]
    else:
        return value


register.filter('mytag_cuturl', mytag_cuturl)


def m_gfyid(value):
    return value.split('/')[-1]


register.filter('m_gfyid', m_gfyid)


def m_gifvid(value):
    return value.split('/')[-1].split('.')[0]


register.filter('m_gifvid', m_gifvid)


def i_minus(value, para):
    return value - para


register.filter('i_minus', i_minus)


def m_bs(value):
    return value.replace('\n', '\n\n')


register.filter('m_bs', m_bs)

def get163(value):

    return '<p><iframe class="audio"   height=87   frameborder="no" border="0" marginwidth="0" marginheight="0"   src="http://music.163.com/outchain/player?type=2&id='+value.split('=')[-1]+'&auto=0&height=66"></iframe><p>'


register.filter('get163', get163)

def get_video(value):
    # 加p换行，class
    pattern = re.compile(r'http:\/\/music.163.com\/\#\/song\?id=([0-9]+)')
    value = pattern.sub(
        r'<p><iframe class="audio"   height=87   frameborder="no" border="0" marginwidth="0" marginheight="0"   src="http://music.163.com/outchain/player?type=2&id=\1&auto=0&height=66"></iframe><p>',
        value)
    pattern = re.compile(r'(http.*\.mp3)')

    value = pattern.sub(
        r'<p><audio loop="loop" preload="meta" controls="controls" src="\1">您的浏览器不支持 audio 标签。</audio><p>',
        value)

    return value


register.filter('get_video', get_video)


def mfind(value, para):
    return value.find(para) > -1


register.filter('mfind', mfind)


def nozero(value):
    if value == 0:
        return ''
    return value


register.filter('nozero', nozero)


def get_link(value):
    pattern = re.compile(r'http(s|)://(\S+)')
    value = pattern.sub(
        r'[](http://\2)',
        value)

    return value


register.filter('get_link', get_link)

def shorten_link(value):

    return value.split('/')[2].replace('www.','')


register.filter('shorten_link', shorten_link)

def pictype(value):
    if value.emo_pic:
        return 'emo_pic'
    if value.pic_height>1 and value.pic_width>1:
        if value.pic_height/float(value.pic_width)>1.4:
            return 'tall_pic'
        if value.pic_height/float(value.pic_width)<0.6:
            return 'fat_pic'

    return 'sq_pic'


register.filter('pictype', pictype)

def stripxxx(value):

    return value.replace('🌚', '')


register.filter('stripxxx', stripxxx)
def param2(value, para):
    return [value, para]


register.filter('param2', param2)

def replace(value, para):
    return value[0].replace( value[1],para)


register.filter('replace', replace)


def paramadd(value, para):
    return value.extend(para)


register.filter('paramadd', paramadd)


def none_add(value, para):
    if not para:
        return value
    else:
        return value+para


register.filter('none_add', none_add)

def concatstr(value, para):
    return value+'：'+para


register.filter('concatstr', concatstr)

def modelcount(value, para):
    if para == 'favourite':
        for aa in value[0]:
            if aa.type == 3 and aa.user == value[1]:
                return True
    elif para == 'collect':
        for aa in value[0]:
            if aa.type == 1 and aa.user == value[1]:
                return True
    elif para == 'later':
        for aa in value[0]:
            if aa.type == 2 and aa.user == value[1]:
                return True
    return False


register.filter('modelcount', modelcount)