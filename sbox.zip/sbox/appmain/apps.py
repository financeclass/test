from django.apps import AppConfig


class AppmainConfig(AppConfig):
    name = 'appmain'
