# coding:utf-8
from __future__ import unicode_literals
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render, get_object_or_404
from .models import *
from .forms import *
import socket
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from functools import reduce
from django.forms import HiddenInput
from django.conf import settings
import os
from random import choice
import requests
import json
import re
from django.views.decorators.csrf import csrf_exempt
import oss2
import sys

from .view_rank import *
from .view_edit import *
from .view_util import *
from .view_ajax import *
from .view_wx import *
from django.http.response import HttpResponse, HttpResponseBadRequest
from django.views.decorators.csrf import csrf_exempt

from wechat_sdk import WechatBasic
from wechat_sdk.exceptions import ParseError
from wechat_sdk.messages import TextMessage


if int(sys.version[0]) == 2:
    eval("reload(sys),sys.setdefaultencoding('utf-8')")

user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36"
headers = {"User-Agent": user_agent}


def biaoqing(request):
    name = request.GET.get('name', None)
    url = 'https://www.doutula.com/api/search?keyword='+name+'&mime=0&page=2'
    try:
        pics = requests.get(url, headers=headers).json()['data']['list']
    except Exception as e:
        errmsg = 1
        return render(request, 'appmain/wx/biaoqing.html', locals())
    if len(pics) == 0:
        errmsg = 2
        return render(request, 'appmain/wx/biaoqing.html', locals())

    pics = [aa['image_url'] for aa in pics]
    return render(request, 'appmain/wx/biaoqing.html', locals())


wechat_instance = WechatBasic(
    token='wxbd',
    appid='wx8cc984e68b81f5f5',

)
# https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx7ac5b762cc3ea065&redirect_uri=http://bbqcr.cn/&response_type=code&scope=snsapi_base&state=1#wechat_redirect
@csrf_exempt
def wx(request):
    # if  1:
    # echostr = request.GET.get('echostr', '')
    #     return HttpResponse(echostr)
    try:
        wechat_instance.parse_data(data=request.body)
    except Exception as e:
        return HttpResponseBadRequest('Invalid XML Data')

    # 获取解析好的微信请求信息
    message = wechat_instance.get_message()
    # 关注事件以及不匹配时的默认回复
    response = wechat_instance.response_text(
        content=(
            '感谢您的关注！\n\n想看什么？\n给我留言吧~'
        ))
    if isinstance(message, TextMessage):
        # 当前会话内容
        content = message.content.strip()
        if content == 'sdfsdfsdfwekjdjj83j':
            reply_text = (
                '目前支持的功能：\n1. 关键词后面加上【教程】两个字可以搜索教程，'
                '比如回复 "Django 后台教程"\n'
                '2. 回复任意词语，查天气，陪聊天，讲故事，无所不能！\n'
                '还有更多功能正在开发中哦 ^_^\n'
                '【<a href="http://www.ziqiangxuetang.com">自强学堂手机版</a>】'
            )
        elif content.find('表情') > -1:
            biaoqing = content.replace('表情', '').replace('+', '').strip()
            response = wechat_instance.response_news([
                {
                    'title': biaoqing,
                    'picurl': 'https:\/\/ws3.sinaimg.cn\/bmiddle\/9150e4e5ly1fgm5wqqh0oj205i05b74c.jpg',
                    'description': '喜欢就分享一下呗',
                    'url': 'https://www.xbangdan.com/biaoqing?name=' + biaoqing,
                },
                # {
                #     'title': '百度',
                #     'picurl': 'https://i.imgur.com/I2xEVNG.jpg',
                #     'url': 'http://www.xbangdan.com',
                # }
            ])
            return HttpResponse(response, content_type="application/xml")
        else:
            reply_text = '回复  "词语"+表情  \n获得相应表情包~\n其他功能，敬请期待'

        response = wechat_instance.response_text(content=reply_text)

    return HttpResponse(response, content_type="application/xml")


def getall():
    pass


configs = {'page_num': 20}


def home(request):
    qqcode = request.GET.get('code', None)
    if qqcode:
        url = 'https://graph.qq.com/oauth2.0/token?grant_type=authorization_code&client_id=101436196&client_secret=ef521a77805f15bd75bbedaf5b84deb9&redirect_uri=http%3a%2f%2fxbangdan.com%3ftype%3dqqrecall&code=' + qqcode
        r = requests.get(url, data={})
        token = r.text.split('&')[0].split('=')[1]
        url = 'https://graph.qq.com/oauth2.0/me?access_token=' + token
        r = requests.get(url, data={})
        openid = r.text.split('"')[-2]
        print(openid)
        url = 'https://graph.qq.com/user/get_user_info?access_token=' + token + '&oauth_consumer_key=101436196&openid=' + openid
        r = requests.get(url, data={})
        print(r.text)
        if not Profile.objects.filter(qqid=openid).exists():
            # u = Profile.objects.get(qqid=openid).user
            if not User.objects.filter(username=r.json()['nickname']).exists():
                u = User.objects.create(username=r.json()['nickname'])
            else:
                u = User.objects.create(username=r.json()['nickname'] + '_' + openid[-4:])
            # u = User.objects.get(username='qq' + openid)
            u.set_password('password3jlk34890sd98f7b54jb6k809sfdf')
            u.save()
            Profile.objects.get_or_create(user=u, qqid=openid, qqname=r.json()['nickname'])
        else:
            u = Profile.objects.get(qqid=openid).user

        login(request, authenticate(username=u.username, password='password3jlk34890sd98f7b54jb6k809sfdf'))
        return HttpResponseRedirect("/index/")

    type = 'home'
    # if request.META.get('HTTP_X_FORWARDED_FOR','00')!='00':
    # ip = request.META['HTTP_X_FORWARDED_FOR']
    # else:
    # ip = request.META['REMOTE_ADDR']
    # url = 'https://free-api.heweather.com/v5/forecast?key=60dd09976905473da467cf7865261183&city='+ip#'123.121.72.210'
    #
    # weather = requests.get(url).json()['HeWeather5'][0]
    # city=weather['basic']['city']+ip
    # weather_s=[aa['date']+aa['cond']['txt_d']+aa['tmp']['min']+'-'+aa['tmp']['max']+'℃'
    # for aa in weather['daily_forecast']][:2]

    site_conf = SiteConf.objects.all()[0]

    # ranks = Ranking.objects.filter(state=0).order_by('order')
    hotchannels = HotChannel.objects.filter(state=0).order_by('order')
    # ranks=list(hotchannels)+list(ranks)
    rankname = '有趣'

    page = int(request.GET.get('page', 1))
    mobile = request.META['HTTP_USER_AGENT'].lower().find('mobile')
    host = request.META['HTTP_HOST']


    # channellist = Channel.objects.all().order_by(
    # '-id')[page * 27 - 27:page * 27]

    # response=render(request, 'appmain/home.html', locals())
    # response.set_cookie("cookie_key","value")
    # print(request.COOKIES.get("cookie_key",0))

    # channellist = [Channel.objects.filter(ranking=aa).order_by('-id')[:6]
    # for aa in ranks]
    # rank_list = [[aa] for aa in ranks]
    # zip_head = zip(rank_list, channellist)

    page = int(request.GET.get('page', 1))
    pagecount = configs['page_num']
    linklist = HotBlog.objects.filter(channel=HotChannel.objects.get(name=rankname),
                                      audit_state=1).order_by(
        '-id')[page * pagecount - pagecount:page * pagecount]

    return render(request, 'appmain/home.html', locals())


def ulinks(request, w, uid):
    type = 'user'
    kind = w
    favdic = ['later', 'collect', 'favourite']
    if w == 'collect':

        listtype = 1
    elif w == 'later':

        listtype = 2
    else:

        listtype = 3
    linklist = FavLink.objects.filter(user=request.user, type=listtype)


    # sort_type = ['title', 'create_time']
    # sort_now = request.GET.get('sort', 'create_time')
    # sort_type.remove(sort_now)
    # if request.GET.get('sort', 'create_time') == 'create_time':
    # linklist = linklist.order_by('-id')
    # elif request.GET.get('sort', 'create_time') == 'title':
    # linklist = linklist.order_by('title')
    pagecount = configs['page_num']

    page = int(request.GET.get('page', 1))

    linklist = linklist[page * pagecount - pagecount:page * pagecount]
    return render(request, 'appmain/user_home.html', locals())


# 一个热门
def hotlink(request, a):
    site_conf = SiteConf.objects.all()[0]
    channels = Channel.objects.all()
    link = get_object_or_404(HotBlog, id=a)

    hotchannels = HotChannel.objects.filter(state=0).order_by('order')
    rank = link.channel
    rankname = rank.name

    if request.method == 'POST':
        new_comment = CommentHot.objects.create(user=request.user if request.user.username else None,
                                                content=request.POST.get('comment', None),
                                                blog=link,
                                                ip=request.META['HTTP_X_FORWARDED_FOR']
                                                if 'HTTP_X_FORWARDED_FOR' in request.META
                                                else request.META['REMOTE_ADDR'])
    comments = CommentHot.objects.filter(blog=link).order_by('-id')
    return render(request, 'appmain/hot/hot_one.html', locals())


# 热门列表
def hot(request, c):
    site_conf = SiteConf.objects.all()[0]

    hotchannels = HotChannel.objects.filter(state=0).order_by('order')
    rank = HotChannel.objects.get(id=c)
    rankname = rank.name

    if Ranking.objects.filter(name=rankname).exists():
        true_rank = Ranking.objects.get(name=rankname)
        channellist = Channel.objects.filter(ranking=true_rank).order_by(
            'id')[:1]

    page = int(request.GET.get('page', 1))
    pagecount = configs['page_num']
    linklist = HotBlog.objects.filter(
        channel=HotChannel.objects.get(id=c), audit_state=1).order_by(
        '-id')[page * pagecount - pagecount:page * pagecount]

    hotchannel = HotChannel.objects.get(id=c)
    return render(request, 'appmain/hot/hots.html', locals())






