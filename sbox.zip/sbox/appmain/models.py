# coding:utf-8
from __future__ import unicode_literals

from django.db import models
from django.utils.encoding import python_2_unicode_compatible
from django.contrib.auth.models import User
from django.forms import ModelForm, HiddenInput, TextInput, Textarea, CheckboxInput, CheckboxSelectMultiple
# from mptt.models import MPTTModel, TreeForeignKey

# 测试用模型


@python_2_unicode_compatible
class Person(models.Model):
    age = models.IntegerField()
    age2 = models.IntegerField(default=1)
    name = models.CharField(max_length=50, null=True, blank=True)
    eee = models.CharField(max_length=50, null=True, blank=True)


    def __str__(self):
        return str(self.age)


@python_2_unicode_compatible
class SiteConf(models.Model):
    name = models.CharField(max_length=50)
    jumbo = models.TextField(max_length=1000, default='Tiiiiiiitle', null=True, blank=True)
    can_post = models.BooleanField(default=True)
    can_comment = models.BooleanField(default=True)
    channels = models.CharField(max_length=255, null=True, blank=True)
    description = models.CharField(max_length=255, null=True, blank=True)
    keywords = models.CharField(max_length=255, null=True, blank=True)
    homepic = models.CharField(max_length=255, null=True, blank=True)


    def __str__(self):
        return self.name


@python_2_unicode_compatible
class SearchBox(models.Model):
    name = models.CharField(max_length=30, unique=True)
    url = models.CharField(max_length=300, null=True)
    search_url = models.CharField(max_length=300, null=True)
    state = models.IntegerField(default=0)
    order = models.IntegerField(default=0)
    describe = models.CharField(max_length=255, null=True, blank=True)
    icon = models.CharField(max_length=30, null=True, blank=True)

    def __str__(self):
        return self.name + self.describe


@python_2_unicode_compatible
class Ranking(models.Model):
    name = models.CharField(max_length=30, unique=True)
    name_en = models.CharField(max_length=30, null=True, blank=True)
    main_tags = models.CharField(max_length=254, null=True, blank=True)
    sub_channel = models.CharField(max_length=30, null=True, blank=True)
    state = models.IntegerField(default=0)
    order = models.IntegerField(default=0)
    content = models.TextField(max_length=254, null=True, blank=True)
    help_url = models.URLField(null=True, blank=True)
    icon = models.CharField(max_length=30, null=True, blank=True)
    pic_url = models.URLField(null=True, blank=True)

    def __str__(self):
        return self.name





@python_2_unicode_compatible
class Channel(models.Model):
    ranking = models.ForeignKey(Ranking, null=True,on_delete=models.CASCADE)
    name = models.CharField(max_length=30)
    name_en = models.CharField(max_length=30, null=True, blank=True)
    main_tags = models.CharField(max_length=254, null=True, blank=True)
    sub_channel = models.CharField(max_length=30, null=True, blank=True)
    state = models.IntegerField(default=0)
    order = models.IntegerField(default=0)
    content = models.TextField(max_length=254, null=True, blank=True)
    help_url = models.URLField(null=True, blank=True)
    icon = models.CharField(max_length=30, null=True, blank=True)
    user = models.ForeignKey(User, null=True, blank=True,on_delete=models.CASCADE)
    pic_url = models.URLField(null=True, blank=True)
    image = models.ImageField(upload_to='channel_image', null=True, blank=True)
    aliurl = models.CharField(null=True, blank=True, max_length=1000)

    def __str__(self):
        return self.name


@python_2_unicode_compatible
class Blog(models.Model):
    content = models.TextField(max_length=1000, blank=True)
    pic_url = models.URLField(null=True, blank=True)
    channel = models.ForeignKey(Channel, null=True,on_delete=models.CASCADE)
    tags = models.CharField(max_length=30, blank=True, null=True)
    is_public = models.BooleanField(default=True)
    on_page = models.BooleanField(default=True)
    top_order = models.IntegerField(default=0, blank=True)
    title = models.CharField(max_length=255, blank=True, null=True)
    user = models.ForeignKey(User, null=True, blank=True,on_delete=models.CASCADE)
    url = models.URLField(null=True, blank=True)
    video_url = models.CharField(null=True, blank=True, max_length=500)
    ups = models.IntegerField(default=0, blank=True)
    downs = models.IntegerField(default=0, blank=True)
    base_score = models.IntegerField(default=0, blank=True)
    image = models.ImageField(upload_to='blog_image', null=True, blank=True)
    aliurl = models.CharField(null=True, blank=True, max_length=1000)

    def __str__(self):
        return self.title


@python_2_unicode_compatible
class HotChannel(models.Model):
    name = models.CharField(max_length=30)
    name_en = models.CharField(max_length=30, null=True, blank=True)
    main_tags = models.CharField(max_length=254, null=True, blank=True)
    sub_channel = models.CharField(max_length=30, null=True, blank=True)
    state = models.IntegerField(default=0)
    order = models.IntegerField(default=0)
    content = models.TextField(max_length=254, null=True, blank=True)
    help_url = models.URLField(null=True, blank=True)
    icon = models.CharField(max_length=30, null=True, blank=True)
    user = models.ForeignKey(User, null=True, blank=True,on_delete=models.CASCADE)
    pic_url = models.URLField(null=True, blank=True)

    def __str__(self):
        return self.name


@python_2_unicode_compatible
class HotBlog(models.Model):
    content = models.TextField(max_length=1000, blank=True)
    pic_url = models.URLField(null=True, blank=True)
    aliurl = models.URLField(null=True, blank=True)
    channel = models.ForeignKey(HotChannel, null=True,on_delete=models.CASCADE)
    tags = models.CharField(max_length=30, blank=True, null=True)
    prefix = models.CharField(max_length=90, blank=True, null=True)
    is_public = models.BooleanField(default=True)
    on_page = models.BooleanField(default=True)
    audit_state = models.IntegerField(default=0, blank=True)
    small_pic = models.BooleanField(default=False)
    emo_pic = models.BooleanField(default=False)
    top_order = models.IntegerField(default=0, blank=True)
    title = models.CharField(max_length=255, blank=True, null=True)
    type = models.CharField(max_length=255, blank=True, null=True)
    user = models.ForeignKey(User, null=True, blank=True,on_delete=models.CASCADE)
    fromurl = models.URLField(null=True, blank=True)
    outurl = models.URLField(null=True, blank=True)
    video_url = models.CharField(null=True, blank=True, max_length=500)
    video_poster = models.URLField(null=True, blank=True)
    ups = models.IntegerField(default=0, blank=True)
    downs = models.IntegerField(default=0, blank=True)
    base_score = models.IntegerField(default=0, blank=True,null=True)
    image = models.ImageField(upload_to='hotblog_image', null=True, blank=True)
    create_time = models.DateTimeField(auto_now_add=True,null=True)
    update_time = models.DateTimeField(auto_now=True,null=True)
    pic_height = models.IntegerField(default=0, blank=True,null=True)
    pic_width = models.IntegerField(default=0, blank=True,null=True)
    has_video = models.BooleanField(default=False)


    def __str__(self):
        return self.content


@python_2_unicode_compatible
class FavLink(models.Model):
    type = models.IntegerField(default=0)
    user = models.ForeignKey(User, null=True,on_delete=models.CASCADE)
    link = models.ForeignKey(HotBlog, null=True,on_delete=models.CASCADE)


    def __str__(self):
        return self.link.content


@python_2_unicode_compatible
class Comments(models.Model):
    blog = models.ForeignKey(Blog, null=True,on_delete=models.CASCADE)
    content = models.TextField(max_length=1000)
    user = models.ForeignKey(User, null=True,on_delete=models.CASCADE)
    status = models.IntegerField(default=0)
    ip = models.CharField(max_length=90, null=True, blank=True)
    type = models.CharField(max_length=90, null=True, blank=True)

    def __str__(self):
        return self.content


@python_2_unicode_compatible
class CommentRank(models.Model):
    blog = models.ForeignKey(Channel, null=True,on_delete=models.CASCADE)
    content = models.TextField(max_length=1000)
    user = models.ForeignKey(User, null=True,on_delete=models.CASCADE)
    status = models.IntegerField(default=0)
    ip = models.CharField(max_length=90, null=True, blank=True)
    type = models.CharField(max_length=90, null=True, blank=True)

    def __str__(self):
        return self.content
@python_2_unicode_compatible
class CommentHot(models.Model):
    blog = models.ForeignKey(HotBlog, null=True,on_delete=models.CASCADE)
    content = models.TextField(max_length=1000)
    user = models.ForeignKey(User, null=True,on_delete=models.CASCADE)
    status = models.IntegerField(default=0)
    ip = models.CharField(max_length=90, null=True, blank=True)
    type = models.CharField(max_length=90, null=True, blank=True)

    def __str__(self):
        return self.content

@python_2_unicode_compatible
class Advice(models.Model):
    content = models.TextField(max_length=1000)
    user = models.ForeignKey(User, null=True,on_delete=models.CASCADE)
    status = models.IntegerField(default=0)
    ip = models.CharField(max_length=90, null=True, blank=True)
    type = models.CharField(max_length=90, null=True, blank=True)

    def __str__(self):
        return self.content

@python_2_unicode_compatible
class Profile(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    pw = models.CharField(max_length=30, null=True, blank=True)

    qqid = models.CharField(max_length=30, null=True, blank=True,unique=True)
    wbid = models.CharField(max_length=30, null=True, blank=True,unique=True)
    qqname = models.CharField(max_length=30, null=True, blank=True)
    wbname = models.CharField(max_length=30, null=True, blank=True)
    setname=models.BooleanField(default=False)

    channel = models.ManyToManyField(Channel)
    search = models.ManyToManyField(SearchBox)
    can_post = models.BooleanField(default=True)
    can_comment = models.BooleanField(default=True)
    # institution = models.CharField(max_length=30, null=True, blank=True)
    email = models.CharField(max_length=30, null=True, blank=True)
    mobile = models.CharField(max_length=30, null=True, blank=True)

    def __str__(self):
        return self.user.username

# @python_2_unicode_compatible
# class SubComments(models.Model):
#     comment = models.ForeignKey(Comments, null=True)
#     content = models.TextField(max_length=1000)
#     user = models.ForeignKey(User, null=True)
#     status = models.IntegerField(default=0)
#
#
#     def __str__(self):
#         return self.content


@python_2_unicode_compatible
class WxCraw(models.Model):
    isgood = models.NullBooleanField(blank=True, null=True)
    posterScreenName = models.CharField(max_length=30, blank=True, null=True)
    wxid = models.CharField(max_length=30, blank=True, null=True)
    myname = models.CharField(max_length=30, blank=True, null=True)
    cate = models.CharField(max_length=30, blank=True, null=True)

    publishDateStr = models.CharField(max_length=30, blank=True, null=True)
    url = models.URLField(null=True, blank=True)
    original = models.NullBooleanField(blank=True, null=True)
    isTop = models.NullBooleanField(blank=True, null=True)

    viewCount = models.IntegerField(blank=True, null=True)
    likeCount = models.IntegerField(blank=True, null=True)
    commentCount = models.IntegerField(blank=True, null=True)
    wordcount = models.IntegerField(blank=True, null=True)
    imgcount = models.IntegerField(blank=True, null=True)
    videocount = models.IntegerField(blank=True, null=True)

    title = models.CharField(max_length=300, blank=True, null=True)
    abstract = models.TextField(max_length=3000, blank=True, null=True)
    content = models.TextField(max_length=30000, blank=True, null=True)
    comments = models.TextField(max_length=3000, blank=True, null=True)

    update_time = models.DateTimeField(auto_now=True,null=True)

    def __str__(self):
        return str(self.title)
