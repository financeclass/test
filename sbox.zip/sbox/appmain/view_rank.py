# coding:utf-8
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render, get_object_or_404
from .models import *
from .forms import *
import socket
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from functools import reduce
from django.forms import HiddenInput
from django.conf import settings
import os
from random import choice
import requests
import json
import re
from django.views.decorators.csrf import csrf_exempt
import oss2

# 一个明细
def detail(request, a):
    site_conf = SiteConf.objects.all()[0]
    link = get_object_or_404(Blog, id=a)

    hotchannels = HotChannel.objects.filter(state=0).order_by('order')
    rank = link.channel
    rankname = rank.ranking.name

    channels = Channel.objects.all()

    if link.user != request.user and link.is_public is False:
        return HttpResponse(u"无权限")
    if request.method == 'POST':
        new_comment = Comments.objects.create(user=request.user if request.user.username else None,
                                              content=request.POST.get('comment', None),
                                              blog=link,
                                              ip=request.META['HTTP_X_FORWARDED_FOR']
                                              if 'HTTP_X_FORWARDED_FOR' in request.META
                                              else request.META['REMOTE_ADDR'])
    comments = Comments.objects.filter(blog=link).order_by('-id')
    return render(request, 'appmain/rank/rank_one.html', locals())


# 一组排名
def links(request, c):
    site_conf = SiteConf.objects.all()[0]

    hotchannels = HotChannel.objects.filter(state=0).order_by('order')
    rank = Channel.objects.get(id=c)
    rankname = rank.ranking.name

    site_conf = SiteConf.objects.all()[0]
    channels = Channel.objects.all()

    page = int(request.GET.get('page', 1))
    linklist = Blog.objects.extra(
        select={'t': 'ups-downs+base_score'}).filter(
        is_public=True, channel=Channel.objects.get(id=c)).extra(
        order_by=['-t'])[page * 20 - 20:page * 20]
    channel = Channel.objects.get(id=c)

    if request.method == 'POST':
        new_comment = CommentRank.objects.create(user=request.user if request.user.username else None,
                                                 content=request.POST.get('comment', None),
                                                 blog=channel,
                                                 ip=request.META['HTTP_X_FORWARDED_FOR']
                                                 if 'HTTP_X_FORWARDED_FOR' in request.META
                                                 else request.META['REMOTE_ADDR'])
    comments = CommentRank.objects.filter(blog=channel).order_by('-id')
    return render(request, 'appmain/rank/ranklist.html', locals())

# 多组排名
def rank(request, c):
    ranks = Ranking.objects.filter(state=0).order_by('order')
    hotchannels = HotChannel.objects.filter(state=0).order_by('order')
    ranks = list(hotchannels) + list(ranks)
    rank = Ranking.objects.get(id=c)
    rankname = rank.name
    if HotChannel.objects.filter(name=rankname).exists():
        true_rank = HotChannel.objects.get(name=rankname)

    site_conf = SiteConf.objects.all()[0]
    channels = Channel.objects.all()

    page = int(request.GET.get('page', 1))
    pagecount = 24
    channellist = Channel.objects.filter(ranking=Ranking.objects.get(id=c)).order_by(
        '-id')[page * pagecount - pagecount:page * pagecount]

    return render(request, 'appmain/rank/ranks.html', locals())




