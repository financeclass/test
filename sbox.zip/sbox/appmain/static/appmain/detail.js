/**
 * Created by Administrator on 2017/5/5.
 */

//滚动监听
//$(window).scroll(function () {
//    var a = document.getElementById("ttt").offsetTop;
//    if (a >= $(window).scrollTop() && a < ($(window).scrollTop() + $(window).height())) {
//        //alert("div在可视范围");
//    }
//});

$(".vote").click(function () {
    var iid = $(this)[0].id.replace('-up', '').replace('-down', '');
    if ($(this)[0].id.indexOf('up') > -1) {
        $('#score' + iid).html(parseInt($('#score' + iid).text()) + 1);
    } else {
        $('#score' + iid).html(parseInt($('#score' + iid).text()) - 1);
    }
    $(this).addClass('disabled');
    htmlobj = $.ajax({
        url: "/vote/" + '?id=' + $(this)[0].id
        , async: false
    });
});
$(".ajaxo").click(function () {
    htmlobj = $.ajax({
        url: "/ajaxo/" + '?id=' + $(this)[0].id
        , async: false
    });
    //alert(htmlobj.responseText)
    if (htmlobj.responseText == 'collect') {
        $(this).html('已收藏');
        $(this).css('font-weight', 'bold');
    } else if (htmlobj.responseText == 'later') {
        $(this).html('已标记');
        $(this).css('font-weight', 'bold');
    } else if (htmlobj.responseText == 'favourite') {
        $(this).html('已赞');
        $(this).css('font-weight', 'bold');
    }
});


//$(".pic img").click(function () {
//    if (window.innerWidth < 555) {
//    } else {
//
//
//        if ($(this).hasClass('big')) {
//            $(this).css('max-height', '384px');
//            $(this).css('max-width', '384px');
//            $(this).removeClass('big');
//        }
//        else {
//            $(this).css('max-height', '700px');
//            $(this).css('max-width', '700px');
//            $(this).addClass('big');
//        }
//    }
//});



//gfycat
//http://www.raymondselzer.net/blog/embed-gfycat-wordpress-posts/
//$(document).ready(function () {
//    $(".gframe").each(function () {
//        htmlobj = $.ajax({
//            url: "https://gfycat.com/cajax/get/" + $(this).attr('id'), //async: false,
//            success: function (data) {
//                var w;
//                if (window.innerWidth < 555) {
//                    w = window.innerWidth;
//                } else if (data.gfyItem.width / data.gfyItem.height > 1.2) {
//                    w = 600;
//                } else if (data.gfyItem.width / data.gfyItem.height > 0.85) {
//                    w = 450;
//                } else {
//                    w = 333;
//                }
//                var h = w / data.gfyItem.width * data.gfyItem.height;
//                $("#" + data.gfyItem.gfyName).css('width', w);
//                $("#" + data.gfyItem.gfyName).css('height', h);
//                $("#" + data.gfyItem.gfyName).children('.giflid').css('width', w);
//                $("#" + data.gfyItem.gfyName).children('.giflid').css('height', h);
//                $("#" + data.gfyItem.gfyName).children('iframe').css('width', w);
//                $("#" + data.gfyItem.gfyName).children('iframe').css('height', h);
//                //alert(data.gfyItem.width);
//            }
//        });
//
//    });
//});

$(".video-js").each(function () {
    $(this).on("play", function () {
          if (window.innerWidth < 555) {
    } else {
              //$(this).css('height', '422px');
              $(this).parent().parent().css('height', '360px');
              $(this).parent().parent().css('width', '585px');
              $(this).parent().css('height', '360px');
              $(this).parent().css('width', '585px');
              //$(this).css('height', '534px');
          }

        //.width(940);
    });
});


$(".contents a").each(function () {
    var aa = $(this).attr('href').replace('www.', '');
    aa = aa.split("/").slice(1, 3).join('.');
    aa = aa.split(".").slice(1, 3).join('.');
    $(this).html(
        //' ' + $(this).text()+
        '<span class="inner-link">'
        + ' <i class="fas fa-external-link-alt"></i> '
        + aa + '</span>');
    $(this).attr('target', '_blank');

});

//展开内容
//$(".detailcontent").each(function () {
//    var aa = $(this)[0].offsetHeight;
//    if (aa>310){$(this).css('max-height', '168px');}
//
//});
