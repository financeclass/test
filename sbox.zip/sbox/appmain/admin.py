from django.contrib import admin

from .models import *

# from reversion.admin import VersionAdmin
#
# @admin.register(Person)
# class PersonAdmin(VersionAdmin):
# pass

class blogAdmin(admin.ModelAdmin):
    list_display = ('title', 'channel')

    list_filter = ('user',)


class ChannelAdmin(admin.ModelAdmin):
    list_display = ('name', 'name_en')


class SearchBoxAdmin(admin.ModelAdmin):
    list_display = ('name', 'order')


class RankingAdmin(admin.ModelAdmin):
    list_display = ('name', 'order')


class HotBlogAdmin(admin.ModelAdmin):
    list_display = ('create_time', 'content')
    list_filter = ('channel','audit_state')
class WxCrawAdmin(admin.ModelAdmin):
    list_display = ('id','myname', 'title')
    list_filter = ('isgood',)
    list_per_page = 500

admin.site.register(SiteConf)
admin.site.register(FavLink)
admin.site.register(Ranking, RankingAdmin)

admin.site.register(Person)
admin.site.register(Channel, ChannelAdmin)
admin.site.register(Blog, blogAdmin)
admin.site.register(HotChannel)
admin.site.register(HotBlog,HotBlogAdmin)
admin.site.register(Profile)
admin.site.register(SearchBox, SearchBoxAdmin)
admin.site.register(Comments)
admin.site.register(Advice)
admin.site.register(WxCraw,WxCrawAdmin)