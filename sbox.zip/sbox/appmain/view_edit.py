# coding:utf-8
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render, get_object_or_404
from .models import *
from .forms import *
import socket
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from functools import reduce
from django.forms import HiddenInput
from django.conf import settings
import os
from random import choice
import requests
import json
import re
from django.views.decorators.csrf import csrf_exempt
import oss2
import random
from PIL import Image
import io
from .view_util import *
headers = {'content-type': 'application/json',
           'User-Agent': 'MQQBrowser/26 Mozilla/5.0 (Linux; U; Android 2.3.7; zh-cn; MB200 Build/GRJ22; CyanogenMod-7) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1'}

@login_required(login_url="/userlogin/")
def hot_post(request):
    if request.method == 'POST':
        if request.user.is_staff:
            form = hot_post_form_staff(request.POST, request.FILES)
        else:
            form = hot_post_form(request.POST, request.FILES)
        if form.is_valid():
            if request.user.is_staff:
                newblog = HotBlog.objects.create(title=form.cleaned_data['title'],
                                                 channel=HotChannel.objects.get(name=form.cleaned_data['channel']),
                                                 content=form.cleaned_data['content'],
                                                 outurl=form.cleaned_data['url'],
                                                 type=form.cleaned_data['type'],
                                                 # video_url=form.cleaned_data['video_url'],
                                                 has_video=form.cleaned_data['has_video'],
                                                 small_pic=form.cleaned_data['is_smallpic'],
                                                 emo_pic=form.cleaned_data['is_emopic'],
                                                 # image=form.cleaned_data['pic'],
                                                 user=request.user,
                                                 base_score = random.randint(1,30),
                                                 is_public=True,
                                                 audit_state=1)
                if form.cleaned_data['video_url'].find('miaopai.com/show')>-1:
                    miaopai_video=form.cleaned_data['video_url'].split('/')[4].split('__')[0]
                    newblog.video_url='https://gslb.miaopai.com/stream/'+miaopai_video+'__.mp4'

                else:
                    newblog.video_url=form.cleaned_data['video_url']

                if form.cleaned_data['pic_url_to_save']  and \
                        (form.cleaned_data['pic_url_to_save'].find('sinaimg.cn')>-1
                         or form.cleaned_data['pic_url_to_save'].find('gfycat')>-1
                        or form.cleaned_data['pic_url_to_save'].find('imgur')>-1):
                    newblog.pic_url = form.cleaned_data['pic_url_to_save']

                elif form.cleaned_data['pic_url_to_save'] and form.cleaned_data['pic_url_to_save'].find('sinaimg.cn')==-1:
                    print(form.cleaned_data['pic_url_to_save'].find('wx2.sinaimg.cn'))
                    print(form.cleaned_data['pic_url_to_save'])
                    html = requests.get(url=form.cleaned_data['pic_url_to_save'], headers=headers   )
                    files = {'image': html.content}
                    imgur=requests.post( 'http://192.169.196.55:8000/imgur/', files=files)
                    newblog.pic_url = imgur.json()['data']['link']
                    newblog.pic_width=Image.open(io.BytesIO( html.content)).size[0]
                    newblog.pic_height=Image.open(io.BytesIO( html.content)).size[1]

                elif form.cleaned_data['pic']:
                    print(222)
                    # html = requests.get(url=form.cleaned_data['pic_url_to_save'], headers=headers   )
                    files = {'image': form.cleaned_data['pic']}
                    imgur=requests.post( 'http://192.169.196.55:8000/imgur/', files=files)

                    newblog.pic_url = imgur.json()['data']['link']
                    newblog.pic_width=Image.open(form.cleaned_data['pic']).size[0]
                    newblog.pic_height=Image.open( form.cleaned_data['pic']).size[1]

                newblog.save()

            else:
                newblog = HotBlog.objects.create(title=form.cleaned_data['title'],
                                                 channel=HotChannel.objects.get(name=form.cleaned_data['channel']),
                                                 content=form.cleaned_data['content'],
                                                 outurl=form.cleaned_data['url'],
                                                 # pic_url=form.cleaned_data['pic_url'],
                                                 # video_url=form.cleaned_data['video_url'],
                                                 image=form.cleaned_data['pic'],
                                                 user=request.user,
                                                 is_public=True)
                upload_image(newblog)

            return HttpResponseRedirect("/hotlink/" + str(newblog.id))
        else:
            return render(request, 'appmain/hot/hot_post.html', locals())
    else:
        if request.user.is_staff:
            form = hot_post_form_staff(initial={'is_show':True,'channel':'有趣'})

        else:
            form = hot_post_form()
        return render(request, 'appmain/hot/hot_post.html', locals())


@login_required(login_url="/userlogin/")
def profileset(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST)
        if form.is_valid():
            # 多选
            pp = Profile.objects.get(user=request.user)
            pp.search.clear()
            for aaa in form.cleaned_data['search']:
                pp.search.add(aaa)
            Profile.objects.filter(user=request.user).update(
                can_comment=True)
            return HttpResponseRedirect("/home/")
        else:
            return render(request, 'appmain/profile.html', locals())
    else:
        form = ProfileForm(instance=Profile.objects.get_or_create(user=request.user)[0])
        return render(request, 'appmain/profile.html', locals())


@login_required(login_url="/userlogin/")
def addone(request):
    if request.method == 'POST':
        form = BlogForm(request.POST, request.FILES)
        if form.is_valid():
            if int(request.GET.get('id', 0)) == 0:
                newblog = Blog.objects.create(title=form.cleaned_data['title'],
                                              channel=Channel.objects.get(id=request.GET.get('channel', 0)),
                                              content=form.cleaned_data['content'],
                                              # url=form.cleaned_data['url'],
                                              # pic_url=form.cleaned_data['pic_url'],
                                              # video_url=form.cleaned_data['video_url'],
                                              image=form.cleaned_data['image'],
                                              user=request.user,
                                              is_public=True)
                print(form.cleaned_data['image'])
                upload_image(newblog)

                return HttpResponseRedirect("/c/" + str(request.GET.get('channel', 0)))
            else:
                Blog.objects.filter(id=request.GET.get('id', 0)).update(
                    title=form.cleaned_data['title'],
                    # image=form.cleaned_data['image'],

                    content=form.cleaned_data['content'],
                    # url=form.cleaned_data['url'],
                    # pic_url=form.cleaned_data['pic_url'],
                )
                if form.cleaned_data['image']:
                    bb = Blog.objects.filter(id=request.GET.get('id', 0))[0]
                    bb.image = form.cleaned_data['image']
                    bb.save()
                    upload_image(bb)

                return HttpResponseRedirect("/a/" + str(request.GET.get('id', 0)))
        else:
            return render(request, 'appmain/mark.html', locals())

    elif int(request.GET.get('id', 0)) > 0:
        thebolg = Blog.objects.get(id=request.GET.get('id', 0))
        form = BlogForm(instance=thebolg)
        return render(request, 'appmain/mark.html', locals())
    else:
        form = BlogForm()
        return render(request, 'appmain/mark.html', locals())


@login_required(login_url="/userlogin/")
def addlist(request):
    if request.method == 'POST':
        form = ListForm(request.POST, request.FILES)
        if form.is_valid():
            if int(request.GET.get('id', 0)) == 0:
                newblog = Channel.objects.create(name=form.cleaned_data['name'],
                                                 ranking=Ranking.objects.get(id=request.GET.get('rank', 0)),
                                                 content=form.cleaned_data['content'],
                                                 # url=form.cleaned_data['url'],
                                                 image=form.cleaned_data['image'],
                                                 # video_url=form.cleaned_data['video_url'],
                                                 # tags=form.cleaned_data['tags'],
                                                 user=request.user,
                                                 # is_public=True
                )
                print(form.cleaned_data['image'])
                upload_image(newblog)

            else:
                Channel.objects.filter(id=request.GET.get('id', 0)).update(
                    name=form.cleaned_data['name'],

                    content=form.cleaned_data['content'],
                    # url=form.cleaned_data['url'],
                    # pic_url=form.cleaned_data['pic_url'],
                )
                if form.cleaned_data['image']:
                    bb = Channel.objects.filter(id=request.GET.get('id', 0))[0]
                    bb.image = form.cleaned_data['image']
                    bb.save()
                    upload_image(bb)

            return HttpResponseRedirect("/r/" + str(request.GET.get('rank', 0)))
        else:
            return render(request, 'appmain/mark.html', locals())

    elif int(request.GET.get('id', 0)) > 0:
        thebolg = Channel.objects.get(id=request.GET.get('id', 0))
        form = ListForm(instance=thebolg)
        return render(request, 'appmain/mark.html', locals())
    else:
        form = ListForm()
        return render(request, 'appmain/mark.html', locals())


@login_required(login_url="/userlogin/")
def mark(request):
    if request.method == 'POST':
        form = BlogForm(request.POST)
        if form.is_valid():
            if int(request.GET.get('edit', 0)) == 0:
                newblog = Blog.objects.create(title=form.cleaned_data['title'],
                                              channel=form.cleaned_data['channel'],
                                              content=form.cleaned_data['content'],
                                              url=form.cleaned_data['url'],
                                              pic_url=form.cleaned_data['pic_url'],
                                              video_url=form.cleaned_data['video_url'],
                                              tags=form.cleaned_data['tags'],
                                              user=request.user,
                                              is_public=True)
            else:
                Blog.objects.filter(id=request.GET.get('linkid', 0)
                                    # ,user=request.user
                ).update(title=form.cleaned_data['title'],
                         channel=form.cleaned_data['channel'],
                         video_url=form.cleaned_data['video_url'],
                         tags=form.cleaned_data['tags'],
                         pic_url=form.cleaned_data['pic_url'],
                         content=form.cleaned_data['content'],
                         url=form.cleaned_data['url'], )
            return HttpResponseRedirect("/u/" + str(request.user.id))
        else:
            return render(request, 'appmain/mark.html', locals())
    elif int(request.GET.get('linkid', 0)) > 0:
        thebolg = Blog.objects.get(id=request.GET.get('linkid', 0))
        form = BlogForm(instance=thebolg)
        return render(request, 'appmain/mark.html', locals())
    else:
        form = BlogForm()
        return render(request, 'appmain/mark.html', locals())

