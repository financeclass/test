# coding:utf-8
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render, get_object_or_404
from .models import *
from .forms import *
import socket
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from functools import reduce
from django.forms import HiddenInput
from django.conf import settings
import os
from random import choice
import requests
import json
import re
from django.views.decorators.csrf import csrf_exempt
import oss2

access_key_id = os.getenv('OSS_TEST_ACCESS_KEY_ID', 'LTAI578PDTEUP3V7')
access_key_secret = os.getenv('OSS_TEST_ACCESS_KEY_SECRET', '5tmwueUHJGVLC3v0vBGEvrA0QC7ZcS')
bucket_name = os.getenv('OSS_TEST_BUCKET', 'adonepic')
endpoint = os.getenv('OSS_TEST_ENDPOINT', 'http://oss-cn-beijing.aliyuncs.com')
bucket = oss2.Bucket(oss2.Auth(access_key_id, access_key_secret), endpoint, bucket_name)


def upload_image(newblog):
    if newblog.image:

        ff = newblog.image.url.split('/')[-2] + '_' + newblog.image.url.split('/')[-1]
        locpic = 'collected_media/' + newblog.image.url.split('/')[-2] + '/' + newblog.image.url.split('/')[-1]
        bucket.put_object_from_file(ff, locpic)
        aliurl = bucket.sign_url('GET', ff, 60 * 60 * 24 * 365 * 3)
        newblog.aliurl = aliurl
        newblog.save()
        return 1
    else:
        return 0


def space(request):
    if request.method == 'POST':
        new_comment = Advice.objects.create(user=request.user if request.user.username else None,
                                            type='advice',

                                            content=request.POST.get('comment', None))
        returns = '感谢你的反馈！'
    return render(request, 'appmain/util/space.html', locals())



def wbrecall(request):
    if request.GET.get('error', '') == 'access_denied':
        return HttpResponseRedirect('/')
    code = request.GET.get('code', 0)
    url = 'https://api.weibo.com/oauth2/access_token?client_id=3318205046&client_secret=80b8f46305de2bfa12d7394557155c97&grant_type=authorization_code&redirect_uri=http://www.xbangdan.com/wbrecall&code=' + code
    r = requests.post(url, data={})
    show = requests.get(
        'https://api.weibo.com/2/users/show.json?access_token=' + r.json()['access_token'] + '&uid=' + r.json()['uid'],
    )

    if not Profile.objects.filter(wbid=r.json()['uid']).exists():
        if not User.objects.filter(username=show.json()['name']).exists():
            u = User.objects.create(username=show.json()['name'])
        else:
            u = User.objects.create(username=show.json()['name'] + '_' + r.json()['uid'][-4:])

        # User.objects.create(username='wb' + r.json()['uid'])
        # u = User.objects.get(username='wb' + r.json()['uid'])
        u.set_password('password3jlk34890sd98f7b54jb6k809sfdf')
        u.save()
        Profile.objects.get_or_create(user=u, wbid=r.json()['uid'], wbname=show.json()['name'])
    else:
        u = Profile.objects.get(wbid=r.json()['uid']).user

    login(request, authenticate(username=u.username, password='password3jlk34890sd98f7b54jb6k809sfdf'))
    return HttpResponseRedirect('/index/')


def register(request):
    if request.method == 'POST':
        try:
            User.objects.create(username=request.POST.get('username', None), is_staff=False)
            u = User.objects.get(username=request.POST.get('username', None))

            u.set_password(request.POST.get('password', None))
            u.save()
            Profile.objects.get_or_create(user=u, can_comment=False, pw=request.POST.get('password', None))
            login(request, authenticate(username=request.POST.get('username', None),
                                        password=request.POST.get('password', None)))
            return HttpResponseRedirect("/index/")
        except Exception as e:
            print(e)
            error_msg = '用户名已占用'
            return render(request, 'appmain/util/register.html', locals())

    else:
        return render(request, 'appmain/util/register.html', locals())


def file(request):
    with open('baidu_verify_1scVq4X1Ef.html') as f:
        c = f.read()
    return HttpResponse(c)



def userlogin(request):
    if request.method == 'POST':
        auth = authenticate(username=request.POST.get('username', None),
                            password=request.POST.get('password', None))
        if auth is not None:
            login(request, auth)
            # todo: login next 无效
            return HttpResponseRedirect('/index/')
        else:
            return render(request, 'appmain/util/login.html', {'error_msg': '用户不存在或密码错误'})
    else:
        return render(request, 'appmain/util/login.html')


def userlogout(request):
    logout(request)
    return HttpResponseRedirect("/")

def index(request):
    return HttpResponseRedirect("/")

def test(request):
    aa = str(socket.gethostname())
    for aaa in request.META:
        aa = aa + '</br>' + '【' + aaa + '】' + str(request.META[aaa])

    return HttpResponse(aa)


def testhtml(request):
    with open('F:\\emacs\\new  02.txt', 'r',encoding='utf8') as f:

        aa=[["".join(cc.split())  for cc in bb.split('【ttt')[0].strip('[]').replace('https', ' https').split(' ') if len(cc)>1] for bb in f.read().strip().split('\n')]
    return render(request, 'appmain/test.html', locals())


def orgmode(request):
    return render(request, 'appmain/orgtest.html', locals())




def search(request):
    site_conf = SiteConf.objects.all()[0]
    channels = Channel.objects.all()
    search_box = SearchBox.objects.all().order_by('order')
    # if request.user.is_authenticated():
    # search_box_temp = Profile.objects.get(user=request.user).search.all().order_by('order')
    # if len(search_box_temp) > 0:
    # search_box = search_box_temp

    fisrt_search = search_box[0].id
    # page = int(request.GET.get('page', 1))
    # linklist = Blog.objects.filter(is_public=True
    # , channel=Channel.objects.get(name_en=c)).order_by(
    # '-id')[page * 9 - 9:page * 9]
    # channel = Channel.objects.get(name_en=c)
    return render(request, 'appmain/search.html', locals())
