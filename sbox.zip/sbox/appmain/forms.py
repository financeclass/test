# coding:utf-8
__author__ = 'Administrator'
from django.forms import ModelForm, HiddenInput, TextInput, Textarea, CheckboxInput, CheckboxSelectMultiple
from .models import *
from django import forms
from django.forms import fields
from django.forms import widgets


class hot_post_form(forms.Form):
    channel = fields.ChoiceField(
        choices=(('有趣', '有趣')
                 , ('视频', '视频')
                 , ('影视', '影视')
                 , ('文章', '文章')
                 # , ('小说', '小说')
                 ,),  # 定义下拉框的选项，元祖第一个值为option的value值，后面为html里面的值
        initial='有趣',  # 默认选中第二个option
        widget=widgets.RadioSelect  # 插件表现形式为单选按钮
    )

    title = fields.CharField(
        widget=widgets.TextInput()
        # 定义生成的html标签类型是input的text框，attrs={'id': 'i1', 'class': 'c1'}代表在这个标签中添加属性ID为i1，添加class为c1
    )

    url = forms.URLField()

    content = forms.CharField(
        widget=widgets.Textarea()
    )

    pic = forms.FileField()

    def __init__(self, *args, **kwargs):
        super(hot_post_form, self).__init__(*args, **kwargs)
        self.fields['content'].label = '内容'
        self.fields['pic'].label = '图片'
        self.fields['url'].label = '链接<span style="color:grey;font-size:0.8em">  (可选)</span>'
        self.fields['title'].label = '标题'
        self.fields['channel'].label = '频道'
        self.fields['content'].required = False
        self.fields['pic'].required = False
        self.fields['url'].required = False
        self.fields['title'].required = False
        self.fields['channel'].required = False

class hot_post_form_staff(forms.Form):
    is_show = forms.BooleanField(required=False)
    channel = fields.ChoiceField(
        choices=(('有趣', '有趣')
                 , ('视频', '视频')
                 , ('影视', '影视')
                 , ('文章', '文章'),
                 # ('小说', '小说'),
        ),  # 定义下拉框的选项，元祖第一个值为option的value值，后面为html里面的值
        initial='有趣',  # 默认选中第二个option
        widget=widgets.RadioSelect  # 插件表现形式为单选按钮
    )
    type = fields.CharField(
        widget=widgets.TextInput(attrs={'spellcheck': 'false'})
        # 定义生成的html标签类型是input的text框，attrs={'id': 'i1', 'class': 'c1'}代表在这个标签中添加属性ID为i1，添加class为c1
    )
    url = forms.URLField(widget=widgets.TextInput(attrs={'spellcheck': 'false'}))
    title = fields.CharField(
        widget=widgets.TextInput(attrs={'spellcheck': 'false'})
        # 定义生成的html标签类型是input的text框，attrs={'id': 'i1', 'class': 'c1'}代表在这个标签中添加属性ID为i1，添加class为c1
    )
    content = forms.CharField(
        widget=widgets.Textarea(attrs={'spellcheck': 'false'}),

    )




    pic = forms.FileField()
    has_video = forms.BooleanField(required=False)
    is_smallpic = forms.BooleanField(required=False,label='侧边图')
    is_emopic = forms.BooleanField(required=False,label='表情图')

    pic_url_to_save= forms.URLField()
    video_url= forms.URLField(required=False,label='视频链接')






    def __init__(self, *args, **kwargs):
        super(hot_post_form_staff, self).__init__(*args, **kwargs)
        self.fields['content'].label = '内容'
        self.fields['has_video'].label = '包含视频'
        self.fields['is_show'].label = '是否展示'
        self.fields['pic_url_to_save'].label = '图片链接'
        self.fields['pic'].label = '图片'
        self.fields['type'].label = '类型'
        self.fields['url'].label = '链接<span style="color:grey;font-size:0.8em">  </span>'
        self.fields['title'].label = '标题'
        self.fields['channel'].label = '频道'
        self.fields['content'].required = False
        self.fields['pic'].required = False
        self.fields['pic_url_to_save'].required = False
        self.fields['type'].required = False
        self.fields['url'].required = False
        self.fields['title'].required = False
        self.fields['channel'].required = False


class ListForm(ModelForm):
    class Meta:
        model = Channel
        fields = ( 'name',
                   # 'url',
                   # 'channel',
                   # 'tags',
                   'content'
                   # , 'pic_url'
                   , 'image'
        )
        widgets = {'content': Textarea(attrs={'class': 'form-control', 'placeholder': ''}),

                   'pic_url': TextInput(attrs={'class': 'form-control', 'placeholder': '复制图片链接'}),
                   # 'is_public': CheckboxInput(),
        }

    def __init__(self, *args, **kwargs):
        super(ListForm, self).__init__(*args, **kwargs)
        self.fields['content'].required = False
        # self.fields['url'].required = False
        # self.fields['tags'].required = False
        # self.fields['channel'].required = False
        self.fields['image'].required = False
        # self.fields['pic_url'].required = False
        # self.fields['video_url'].required = False

        self.fields['content'].label = '榜单说明'
        self.fields['name'].label = '名称'
        # self.fields['pic_url'].label = '封面<p class="text-muted">建议将图片上传微博相册后复制链接</p>'


class BlogForm(ModelForm):
    class Meta:
        model = Blog
        fields = ( 'title',
                   # 'url',
                   # 'channel',
                   # 'tags',
                   'content', 'image'
                   # , 'pic_url'
        )
        widgets = {'content': Textarea(attrs={'class': 'form-control'
            , 'placeholder': '简介\r评价\r资源链接（链接与文字请用空格隔开）'}),
                   # 'pic_url': TextInput(attrs={'class': 'form-control','placeholder':'复制图片链接'}),

                   # 'title': TextInput(attrs={'class': 'form-control'}),
                   # 'is_public': CheckboxInput(),
        }

    def __init__(self, *args, **kwargs):
        super(BlogForm, self).__init__(*args, **kwargs)
        self.fields['content'].required = False
        self.fields['image'].required = False
        # self.fields['tags'].required = False
        # self.fields['channel'].required = False
        # self.fields['pic_url'].required = False
        # self.fields['video_url'].required = False

        self.fields['content'].label = '推荐理由'
        self.fields['image'].label = '上传图片'
        self.fields['title'].label = '名称'
        # self.fields['pic_url'].label = '配图<p class="text-muted">建议将图片上传微博相册后复制链接</p>'
        # self.fields['video_url'].label = '视频'
        # self.fields['url'].label = '链接'
        # self.fields['tags'].label = '标签'


class ProfileForm(ModelForm):
    class Meta:
        model = Profile
        fields = (  'search',)
        widgets = {
            # 多选
            'channel': CheckboxSelectMultiple(),
            'search': CheckboxSelectMultiple(),
        }

    def __init__(self, *args, **kwargs):
        super(ProfileForm, self).__init__(*args, **kwargs)

        self.fields['search'].required = False
