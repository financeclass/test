# coding:utf-8
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import render, get_object_or_404
from .models import *
from .forms import *
import socket
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from functools import reduce
from django.forms import HiddenInput
from django.conf import settings
import os
from random import choice
import requests
import json
import re
from django.views.decorators.csrf import csrf_exempt
import oss2


def ajaxo(request):
    ajtype = request.GET.get('id', None)
    if ajtype.find('collect') > -1:
        newhot, one = FavLink.objects.get_or_create(user=request.user,
                                                    link=HotBlog.objects.get(id=int(ajtype.split('-')[1])),
                                                    type=1)
        return HttpResponse('collect')
    elif ajtype.find('later') > -1:
        newhot, one = FavLink.objects.get_or_create(user=request.user,
                                                    link=HotBlog.objects.get(id=int(ajtype.split('-')[1])),
                                                    type=2)
        return HttpResponse('later')
    elif ajtype.find('favourite') > -1:
        newhot, one = FavLink.objects.get_or_create(user=request.user,
                                                    link=HotBlog.objects.get(id=int(ajtype.split('-')[1])),
                                                    type=3)
        return HttpResponse('favourite')

    return HttpResponse(1)

@login_required(login_url="/userlogin/")
def delete(request):
    Blog.objects.filter(id=request.GET.get('linkid', None), user=request.user).delete()
    return HttpResponseRedirect("/u/" + str(request.user.id))


def vote(request):
    votei = request.GET.get('id', None)
    blog = Blog.objects.get(id=int(votei.split('-')[0]))
    if votei.split('-')[1] == 'up':
        blog.ups += 1
        blog.save()
    elif votei.split('-')[1] == 'down':
        blog.downs += 1
        blog.save()
    return HttpResponse(0)

def favlink(request):
    votei = request.GET.get('id', None)
    blog = Blog.objects.get(id=int(votei.split('-')[0]))
    if votei.split('-')[1] == 'up':
        blog.ups += 1
        blog.save()
    elif votei.split('-')[1] == 'down':
        blog.downs += 1
        blog.save()
    return HttpResponse(0)


@csrf_exempt
def posthot(request):
    if request.POST.get('test') == '1':
        if HotBlog.objects.filter(fromurl=request.POST.get('mesglink', None)).exists():
            return HttpResponse('old')
        else:
            return HttpResponse('new')
    else:
        newhot, one = HotBlog.objects.get_or_create(fromurl=request.POST.get('mesglink', None))
        newhot.content = request.POST.get('con', None)
        newhot.pic_url = request.POST.get('img', None)
        newhot.video_url = request.POST.get('vid', None)
        newhot.video_poster = request.POST.get('poster', None)
        newhot.outurl = request.POST.get('outlink', None)
        newhot.title = request.POST.get('title', None)
        newhot.type = request.POST.get('type', None)
        newhot.channel = HotChannel.objects.get(name=request.POST.get('channel', None))
        newhot.small_pic = request.POST.get('small_pic', False)
        newhot.base_score = request.POST.get('likes', None)
        newhot.pic_height = request.POST.get('height', None)
        newhot.pic_width = request.POST.get('width', None)
        newhot.is_video = request.POST.get('is_video', None)

        newhot.save()
        return HttpResponse(0)

@csrf_exempt
def wxcraw(request):
    if  WxCraw.objects.filter(url=request.POST.get('url', None)).exists():

        return HttpResponse('old')
    else:
        newhot, one = WxCraw.objects.get_or_create(url=request.POST.get('url', None))
        newhot.publishDateStr = request.POST.get('publishDateStr', None)
        newhot.posterScreenName = request.POST.get('posterScreenName', None)
        newhot.wxid = request.POST.get('wxid', None)
        newhot.myname = request.POST.get('myname', None)
        newhot.cate = request.POST.get('cate', None)
        newhot.original = request.POST.get('original', None)
        newhot.isTop = request.POST.get('isTop', None)
        newhot.viewCount = request.POST.get('viewCount', None)
        newhot.likeCount = request.POST.get('likeCount', None)
        newhot.commentCount = request.POST.get('commentCount', None)
        newhot.wordcount = request.POST.get('wordcount', None)
        newhot.imgcount = request.POST.get('imgcount', False)
        newhot.videocount = request.POST.get('videocount', None)
        newhot.title = request.POST.get('title', None)
        newhot.abstract = request.POST.get('abstract', None)
        newhot.content = request.POST.get('content', None)
        newhot.comments = request.POST.get('comments', None)
        newhot.save()
        return HttpResponse('ok')

