# -*- coding: utf-8 -*-


class SuspiciousOpenID(Exception):
    pass