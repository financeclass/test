# -*- coding: utf-8 -*-

from wechat_sdk.core.conf import WechatConf
from wechat_sdk.basic import WechatBasic
from wechat_sdk.ext import WechatExt

__all__ = ['WechatConf', 'WechatBasic', 'WechatExt']

__version__ = "0.6.4"
